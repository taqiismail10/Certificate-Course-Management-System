import React from 'react';
import { Link } from 'react-router-dom';

const UpcomingCourses: React.FC = () => {
  // Dummy data for upcoming courses
  const courseList = [
    { id: 1, name: 'Upcoming Course 1', level: 'Beginner' },
    { id: 2, name: 'Upcoming Course 2', level: 'Intermediate' },
    { id: 3, name: 'Upcoming Course 3', level: 'Advanced' },
    { id: 4, name: 'Upcoming Course 4', level: 'Beginner' },
    { id: 5, name: 'Upcoming Course 5', level: 'Beginner' },
  ];

  return (
    <div className="col-md-12">
      <div className="card mb-4">
        <div className="card-body">
          <h5 className="card-title mb-3" style={{ fontSize: "30px", fontWeight: "normal" }}>
            Upcoming Courses
          </h5>
          <div style={{ maxHeight: "200px", overflowY: "scroll" }}>
            <ul className="list-group list-group-flush">
              {courseList.map((course) => (
                <li key={course.id} className="list-group-item d-flex justify-content-between align-items-center">
                  <Link to={`/course-details/${course.id}`}>
                    {course.name} ({course.level})
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UpcomingCourses;
